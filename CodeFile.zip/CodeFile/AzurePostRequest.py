import requests

url = "http://localhost:7003/api/AzureFunction"
data = {"name": "Zeeshan Haider"}

response = requests.post(url, json=data)
print(response.text)
